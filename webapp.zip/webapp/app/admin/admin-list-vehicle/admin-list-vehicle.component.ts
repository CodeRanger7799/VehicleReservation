import { Component, OnInit } from "@angular/core";
import { ListVehicleService } from "../../service/list-vehicle.service";
import { Router } from "@angular/router";

@Component({
  selector: "app-admin-list-vehicle",
  templateUrl: "./admin-list-vehicle.component.html",
  styleUrls: ["./admin-list-vehicle.component.css"]
})
export class AdminListVehicleComponent implements OnInit {
  vehicles;
  searchVehicleList;
  filter: string[] = ["All", "Sedan", "SUV", "Coupe", "Hatchback"];
  constructor(
    private vehicleService: ListVehicleService,
    private router: Router
  ) {}

  ngOnInit() {
    this.getDisplay();
  }
  // get the updated list of vehicles from  the database
  getDisplay() {
    this.vehicleService.getAdminListVehicle().subscribe(data => {
      this.vehicles = data;
      this.searchVehicleList = this.vehicles;
    });
  }
  //Used to Route to the adminEdit component
  onEdit(id) {
    this.router.navigate(["adminEdit", id]);
  }
  // Used to call the delete service by passing the id of the vehicle
  onDelete(id) {
    this.vehicleService.deleteVehicleByID(id).subscribe(data => {
      this.getDisplay();
    });
  }

  // Route to adminAdd component
  addNew() {
    this.router.navigate(["adminAdd"]);
  }

  // Used for searching the vehicles
  onSearch(value: string) {
    this.searchVehicleList = this.vehicles.filter(vehicle =>
      vehicle.name.toLowerCase().includes(value.toLowerCase())
    );
    console.log(this.searchVehicleList);
    this.vehicleService.getSubject().next(this.searchVehicleList);
  }

  // Used for filtering the search of vehicles
  onInput(value: string) {
    this.searchVehicleList = this.vehicles.filter(vehicle =>
      vehicle.name.toLowerCase().includes(value.toLowerCase())
    );
    console.log(this.searchVehicleList);
    this.vehicleService.getSubject().next(this.searchVehicleList);
  }

  // Used for filtering purpose
  onFilter(value) {
    if (value != "All") {
      this.searchVehicleList = this.vehicles.filter(vehicle =>
        vehicle.vehicleType.toLowerCase().includes(value.toLowerCase())
      );
      this.vehicleService.getSubject().next(this.searchVehicleList);
    } else {
      this.searchVehicleList = this.vehicles;
      this.vehicleService.getSubject().next(this.searchVehicleList);
    }
  }
}

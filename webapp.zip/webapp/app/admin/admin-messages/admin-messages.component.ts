import { Component, OnInit } from "@angular/core";
import { MessageServiceService } from "../../service/message-service.service";
import { SmsService } from "../../service/sms.service";
import { User } from "src/app/user/user-reg/user-reg.component";
import { HttpClient } from "@angular/common/http";
import { AuthCredentialService } from "src/app/service/auth-credential.service";

@Component({
  selector: "app-admin-messages",
  templateUrl: "./admin-messages.component.html",
  styleUrls: ["./admin-messages.component.css"]
})
export class AdminMessagesComponent implements OnInit {
  PendingUser;
  constructor(
    private msgService: MessageServiceService,
    private smsService: SmsService,
    private http: HttpClient,
    private auth: AuthCredentialService
  ) {}

  ngOnInit() {
    this.getDisplay();
  }

  // Get updated list of pending users
  getDisplay() {
    this.msgService.getPendingUserList().subscribe(data => {
      this.PendingUser = data;
    });
  }
  // Approval of pending user
  onAccept(u) {
    console.log(this.auth.getSessionToken());

    this.msgService.AcceptUser(u).subscribe(data => {
      this.getDisplay();
      console.log("accept");
      this.smsService
        .sendSMS(
          "Your request for VehicleBar App is approved.",
          u.contactNumber.toString()
        )
        .subscribe(res => {});
      //this.getDisplay()
    });
  }

  // Reject a pending user
  onReject(u) {
    this.msgService.RejectUser(u).subscribe(data => {
      console.log("reject");
      this.getDisplay();
    });
  }
}

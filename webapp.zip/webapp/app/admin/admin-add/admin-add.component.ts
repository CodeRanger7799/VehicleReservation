import { Component, OnInit } from '@angular/core';
import { ListVehicleService } from '../../service/list-vehicle.service';
import { Router } from '@angular/router';
import { Vehicles } from 'src/app/Interfaces/IVehicles';

@Component({
  selector: 'app-admin-add',
  templateUrl: './admin-add.component.html',
  styleUrls: ['./admin-add.component.css']
})
export class AdminAddComponent implements OnInit {
  vehicle
  constructor(private listService:ListVehicleService,private router:Router) { }

  ngOnInit() {
  }

  //Used to add new vehicle detail to database
  Save(data)
  {
    console.log(data)
    this.listService.addVehicle(data).subscribe(data =>
      {
        this.router.navigate(['adminlistVehicle'])
      })
  }

}

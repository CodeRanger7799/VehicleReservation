import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/user/user-reg/user-reg.component';
import { RegServiceService } from 'src/app/service/reg-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-reg',
  templateUrl: './admin-reg.component.html',
  styleUrls: ['./admin-reg.component.css']
})
export class AdminRegComponent implements OnInit {

  user:User
  constructor(private usrService:RegServiceService,private router:Router) { }

  ngOnInit() {

  }

    // Send the registration form to the admin for approval
  onSubmit(data)
  {
  
    
     this.user = { firstName:data.firstName,lastName:data.lastName,age:data.age,gender:data.gender,contactNumber:data.contactNumber,username:data.username,password:data.password}
  
      this.usrService.addAdmin(this.user).subscribe(data =>
        {
          this.router.navigate(['regSuccess'])
        })
  }

}

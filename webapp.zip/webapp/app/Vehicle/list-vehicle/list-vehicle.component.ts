import { Component, OnInit } from "@angular/core";
import { ListVehicleService } from "../../service/list-vehicle.service";
import { Router } from "@angular/router";
import { BookingServiceService } from "src/app/service/booking-service.service";
// Display the list of Vehicle of r a particular  user
@Component({
  selector: "app-list-vehicle",
  templateUrl: "./list-vehicle.component.html",
  styleUrls: ["./list-vehicle.component.css"]
})
export class ListVehicleComponent implements OnInit {
  vehicles;
  searchVehicleList;
  filter: string[] = ["All", "Sedan", "SUV", "Coupe", "Hatchback"];
  constructor(
    private vehicleService: ListVehicleService,
    private router: Router,
    private bookingService: BookingServiceService
  ) {}

  ngOnInit() {
    this.vehicleService.getListVehicle().subscribe(data => {
      this.vehicles = data;
      this.searchVehicleList = this.vehicles;
    });
  }

  clickDisplay() {
    console.log(this.vehicles);
  }

    // Search a particular vehicle 
  onSearch(value: string) {
    this.searchVehicleList = this.vehicles.filter(vehicle =>
      vehicle.name.toLowerCase().includes(value.toLowerCase())
    );
    console.log(this.searchVehicleList);
    this.vehicleService.getSubject().next(this.searchVehicleList);
  }

  // Catch the input entered for searching
  onInput(value: string) {
    this.searchVehicleList = this.vehicles.filter(vehicle =>
      vehicle.name.toLowerCase().includes(value.toLowerCase())
    );
    console.log(this.searchVehicleList);
    this.vehicleService.getSubject().next(this.searchVehicleList);
  }

  // Display the details of a particular vehicle
  onDisplay(id, price) {
    this.bookingService.setPrice(price);
    this.router.navigate(["bookVehicle", id]);
  }

  // Filter the list of vehicle
  onFilter(value) {
    if (value != "All") {
      this.searchVehicleList = this.vehicles.filter(vehicle =>
        vehicle.vehicleType.toLowerCase().includes(value.toLowerCase())
      );
      this.vehicleService.getSubject().next(this.searchVehicleList);
    } else {
      this.searchVehicleList = this.vehicles;
      this.vehicleService.getSubject().next(this.searchVehicleList);
    }
  }
}

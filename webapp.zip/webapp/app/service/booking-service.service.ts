import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { TouchSequence } from 'selenium-webdriver';

@Injectable({
  providedIn: 'root'
})
export class BookingServiceService {
cart
price

  constructor(private http:HttpClient) { }
//Add to cart
  addToCart(cart)
  {
    console.log(cart)
    return this.http.post(`http://localhost:8090/addToCart`,cart)
  }
// Get a particular user cart
  getCart(username)
  {
    return this.http.get(`http://localhost:8090/getCart/${username}`)
  }

  //Get a particular cart item for a particular user
  getCartService(username,vehicleID)
  {
    return this.http.get(`http://localhost:8090/getCartDetails/${username}/${vehicleID}`)
  }

  //Set the cart variable 
  storetoCart(cartnew)
  {
    this.cart=cartnew
  }
  //set the price variable
  setPrice(price)
  {
    this.price=price
  }
  //get the price variable
  getPrice()
  {
    return this.price
  }
}

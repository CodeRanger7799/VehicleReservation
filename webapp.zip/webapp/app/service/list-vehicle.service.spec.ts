import { TestBed } from '@angular/core/testing';

import { ListVehicleService } from './list-vehicle.service';

describe('ListVehicleService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ListVehicleService = TestBed.get(ListVehicleService);
    expect(service).toBeTruthy();
  });
});

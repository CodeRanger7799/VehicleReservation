import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Subject } from "rxjs";
import { Vehicles } from "../Interfaces/IVehicles";

@Injectable({
  providedIn: "root"
})
export class ListVehicleService {
  private subject = new Subject<Vehicles[]>();

  constructor(private http: HttpClient) {}

  getSubject(): Subject<Vehicles[]> {
    return this.subject;
  }
  //Get the list of vehicles for the user
  getListVehicle() {
    return this.http.get("http://localhost:8090/listVehicle");
  }
  //Get the list of vehicle for admin
  getAdminListVehicle() {
    return this.http.get("http://localhost:8090/AdminlistVehicle");
  }
  //Get the vehicle based on ID
  getVehicleById(id) {
    return this.http.get(`http://localhost:8090/vehicle/${id}`);
  }
  //Update the vehicle
  updateVehicle(v, id) {
    return this.http.put(`http://localhost:8090/vehicle/${id}`, v);
  }
  //Add a new vehicle
  addVehicle(v) {
    return this.http.post(`http://localhost:8090/vehicle`, v);
  }
  //Delete a particular vehicle
  deleteVehicleByID(id) {
    return this.http.delete(`http://localhost:8090/vehicle/${id}`);
  }
}

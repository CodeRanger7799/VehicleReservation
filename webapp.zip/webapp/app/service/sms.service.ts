import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { AuthCredentialService } from "./auth-credential.service";
//Send SMS service to user for notification purpose
@Injectable({
  providedIn: "root"
})
export class SmsService {
  url = "https://api.textlocal.in/send";

  constructor(private http: HttpClient, auth: AuthCredentialService) {}

  sendSMS(text: string, number: string) {
    return this.http.get(
      this.url +
        "?apikey=g5LDhBKYxFE-pQt8DZSR9TzJtt8JLTjHPVSkHEzvkt&message=" +
        text +
        "&sender=TXTLCL&numbers=91" +
        number
    );
  }
}

import { Component, OnInit } from '@angular/core';
import { AuthCredentialService } from 'src/app/service/auth-credential.service';
import { Router } from '@angular/router';
import { MessageServiceService } from 'src/app/service/message-service.service';
import { USER } from '../user-details/user-details.component';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {
  username:string
  password:string
  invalidmsg = 'Sorry, you are not yet approved'
  invalid=false
  

  constructor(private auth:AuthCredentialService,private router:Router,private msgService:MessageServiceService) { }

  ngOnInit() {
  }


// Handle the user login by authentication the user entered credentials
  handleLogin()
  {
    this.auth.handleAuthorization(this.username,this.password).subscribe(data =>
      {
        if(data.role === '[ROLE_ADMIN]')
        {
          this.invalid=true
          this.invalidmsg='Sorry, you are an admin, please go to admin login'
        }
        else
        {
          this.invalid=false
          this.router.navigate(['listVehicle'])
        }
      },
      error=>
      {
        if(error.error === 'INVALID_CREDENTIALS')
        { 
          console.log(error)
          this.invalidmsg = 'Wrong credentials'
          this.invalid=true
        }
        else
        {  
          
          this.invalid=true
        }
      })
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentOTPComponent } from './payment-otp.component';

describe('PaymentOTPComponent', () => {
  let component: PaymentOTPComponent;
  let fixture: ComponentFixture<PaymentOTPComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PaymentOTPComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentOTPComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

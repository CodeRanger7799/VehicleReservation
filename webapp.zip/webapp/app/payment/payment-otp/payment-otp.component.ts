import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MessageServiceService } from 'src/app/service/message-service.service';
import { PaymentServiceService } from 'src/app/service/payment-service.service';
import { AuthCredentialService } from 'src/app/service/auth-credential.service';
import { BookingServiceService } from 'src/app/service/booking-service.service';

@Component({
  selector: 'app-payment-otp',
  templateUrl: './payment-otp.component.html',
  styleUrls: ['./payment-otp.component.css']
})
export class PaymentOTPComponent implements OnInit {
recievedotp:number
enteredOTP:number
  constructor(private route:ActivatedRoute,private msgService:MessageServiceService,private router:Router,private payService:PaymentServiceService,private auth:AuthCredentialService,private bookService:BookingServiceService) { }

  ngOnInit() {
    this.recievedotp = this.msgService.getOTP()
    console.log(this.recievedotp)
    
    
  }

// Validation of User Entered OTP with the recieved OTP
  OnOTP()
  {
    console.log(this.enteredOTP)
    if(this.enteredOTP == this.recievedotp)
    {
      this.bookService.addToCart(this.payService.getCart()).subscribe(data =>
        {
          this.router.navigate(['paymentSuccess'])
        })
      

    }
    else
    {
         this.router.navigate(['paymentReject'])
    
    }
  }

}

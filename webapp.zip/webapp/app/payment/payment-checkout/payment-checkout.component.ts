import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MessageServiceService } from 'src/app/service/message-service.service';
import { USER } from 'src/app/user/user-details/user-details.component';
import { AuthCredentialService } from 'src/app/service/auth-credential.service';
import { PaymentServiceService } from 'src/app/service/payment-service.service';
import { SmsService } from 'src/app/service/sms.service';
// Payment gateway
@Component({
  selector: 'app-payment-checkout',
  templateUrl: './payment-checkout.component.html',
  styleUrls: ['./payment-checkout.component.css']
})
export class PaymentCheckoutComponent implements OnInit {
  username
  totalCost

  constructor(private payService: PaymentServiceService, private route: ActivatedRoute, private msgService: MessageServiceService, private auth: AuthCredentialService, private paymentService: PaymentServiceService, private router: Router, private smsService: SmsService) { }

  ngOnInit() {
    this.totalCost = this.route.snapshot.params['amount']
  }

  // Submission of all the payment details of the user to the backend and reception of OTP
  onSubmit(payForm) {
    this.username = this.auth.getSessionUsername()
    this.paymentService.paymentAuthenticate(payForm).subscribe(data => {
      this.msgService.getContactNumber(this.username).subscribe(res => {
        console.log(data)
        console.log(res)
        let ms = 'Your OTP is ' + data
        this.smsService.sendSMS(ms, res.toString()).subscribe(r => {
        })
        this.msgService.setOTP(data)
        this.router.navigate(['paymentOTP'])
      })

    })





  }

}
